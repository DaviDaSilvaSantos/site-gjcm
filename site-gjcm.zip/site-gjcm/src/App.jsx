import { Header } from "./components/Header"
import { MainContent } from "./components/MainContent"
import { Cards } from "./components/Cards"
import { Footer } from "./components/Footer"

export function App(){
  return(
    <div>
      <Header />
      <MainContent />
      <Cards />
      <Footer />
    </div>
  )
}