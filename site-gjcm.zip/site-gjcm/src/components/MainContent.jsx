export function MainContent(){
    return(
        <div>
            <p>Uma verdadeira familia para se viver</p>
            
        </div>
    )
}