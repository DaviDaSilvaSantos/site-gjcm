export function Footer(){
    return(
        <div>
            <img src="logoGJCM.png" alt="logo-gjcm" />
            <h1>Sede Santo!
            
            </h1>
        </div>
    )
}